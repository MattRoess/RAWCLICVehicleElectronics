# Comprehensive Bill of Materials for Battery Electric Vehicle (BEV) Traction Motors

**Report Date:** June 30, 2025

## Executive Summary

This report provides a comprehensive, quantified bill of materials (BOM) for the primary components of modern Battery Electric Vehicle (BEV) traction motors, focusing on copper, permanent magnets, aluminum, and steel. The analysis synthesizes data from technical specifications, industry reports, and academic research to detail the materials used in Permanent Magnet Synchronous Motors (PMSM), Induction Motors (IM), and emerging motor technologies. Key findings include detailed weight and grade specifications for materials such as NdFeB magnets, electrical steel laminations, copper windings, and aluminum housings. The report highlights the critical role of material selection in achieving desired performance characteristics like power density, efficiency, and thermal management, while also addressing the industry's ongoing efforts to mitigate reliance on critical rare earth elements. This document serves as a foundational reference for understanding the material composition of contemporary and future BEV powertrain systems.

## 1. Permanent Magnet Synchronous Motors (PMSM)

Permanent Magnet Synchronous Motors (PMSM) are the dominant technology in the current BEV market, favored for their high efficiency and power density. Their construction relies on a precise combination of high-performance materials, each selected to optimize electromagnetic and thermal performance.

### 1.1. Permanent Magnets (Rotor)

The defining component of a PMSM is its rotor, which contains high-strength permanent magnets. These magnets are critical for generating the magnetic field that interacts with the stator to produce torque.

*   **Material:** The most commonly used material is Neodymium-Iron-Boron (NdFeB), a type of rare earth magnet renowned for its exceptional magnetic strength. The specific grade of NdFeB magnet is chosen based on the required performance and operating temperature of the motor.
*   **Grades and Composition:**
    *   **Standard Grades (e.g., N42, N48):** These grades offer a high magnetic energy product, suitable for many BEV applications. For instance, an N42 grade typically has a maximum energy product of 40-42 MGOe, while an N48 grade offers 45-48 MGOe. The primary rare earth element is Neodymium (Nd), often alloyed with Praseodymium (Pr), making up approximately 30-32% of the magnet's weight.
    *   **High-Temperature Grades (e.g., SH, UH, EH):** For high-performance motors that operate at elevated temperatures, heavy rare earth elements (HREEs) like Dysprosium (Dy) and Terbium (Tb) are added to increase the magnet's coercivity (resistance to demagnetization). The percentage of these elements varies significantly:
        *   **SH Grade (e.g., N42SH):** Typically contains 2-4% Dysprosium.
        *   **UH Grade:** May contain 3-6% Dysprosium.
        *   **EH and AH Grades:** Can contain up to 11% Dysprosium for the most demanding applications, such as high-performance sports car traction motors.
*   **Quantity and Weight:** The amount of magnet material is directly related to the motor's power output. A common industry metric is approximately **7.5 grams of magnet material per kilowatt (kW)** of power. For a typical 100 kW passenger BEV motor, this translates to about 0.75 kg of magnets. However, this can vary widely. Some analyses suggest a range of **1 to 2 kg of magnets per 10 kW of power**, which would imply 10-20 kg for a 100 kW motor. High-performance vehicles with power outputs of 200-400 kW can use anywhere from **20 kg to over 50 kg** of NdFeB magnets. For example, a typical mid-range EV motor might contain approximately **1.2 kg of NdFeB magnets per 100 kW of peak power**.

### 1.2. Stator Windings

The stator windings are responsible for creating the rotating magnetic field that drives the rotor. The material and design of these windings are crucial for motor efficiency and thermal management.

*   **Material:** High-purity copper is the standard material due to its excellent electrical conductivity. The two most common grades are C101 (Oxygen-Free Electronic, OFE) and C110 (Electrolytic Tough Pitch, ETP).
    *   **C101 (CW004A):** With a purity of 99.99% and electrical conductivity exceeding 101% IACS, this grade is preferred for applications demanding the highest efficiency to minimize resistive losses (I²R losses).
    *   **C110 (CDA 110):** With a purity of 99.90% and conductivity around 100% IACS, this grade offers slightly better ductility, making it easier to form into the complex shapes required for modern hairpin or concentrated windings.
*   **Form and Weight:** The copper is used in the form of insulated wire. The total weight of copper in the stator windings depends on the motor's power, voltage, and winding design (e.g., traditional round wire vs. modern hairpin/flat wire). A higher copper fill factor, achieved with rectangular hairpin windings, allows for more copper in the same volume, increasing power density and efficiency. For a typical 150 kW motor, the copper winding weight can range from **8 kg to 15 kg**. For example, a 7.5 kW industrial motor might have 8.3 kg of copper in its stator windings, providing a scalable reference.

### 1.3. Stator and Rotor Core

The core of both the stator and rotor is made from laminations of electrical steel, which guide the magnetic flux.

*   **Material:** Non-oriented (NO) electrical steel, also known as silicon steel, is used. The silicon content (typically 0.5% to 3.5%) increases electrical resistivity, which reduces eddy current losses.
*   **Grades:** The grade is selected based on a trade-off between magnetic performance (core loss) and cost. Common grades for high-performance motors include:
    *   **M270-35A:** A high-performance grade with a maximum core loss of 2.70 W/kg at 1.5T and 50Hz, and a nominal thickness of 0.35 mm. It is often used in high-efficiency motors, including those for electric vehicles.
    *   **M330-35A:** A slightly lower-grade material with a maximum core loss of 3.30 W/kg and the same 0.35 mm thickness. It offers a more cost-effective solution where the highest efficiency is not the sole priority.
    *   **M19 (or equivalent):** A widely used, cost-effective grade for general motor applications. For high-frequency operation in BEVs, thinner laminations (e.g., 0.27 mm or less) of high-grade steel are preferred to minimize losses.
*   **Weight:** The total weight of the steel laminations is the most significant contributor to the motor's overall mass. For a 100-150 kW PMSM, the combined weight of the stator and rotor core can range from **30 kg to 50 kg**.

### 1.4. Motor Housing

The housing provides structural support, protection, and heat dissipation for the motor's internal components.

*   **Material:** Aluminum alloys are the predominant choice due to their low density, high thermal conductivity, and excellent castability.
    *   **A380 (AlSi8Cu3Fe):** This is the most common die-casting alloy, offering a great balance of mechanical properties, castability, and thermal conductivity. It is widely used for motor housings that require intricate shapes and good heat dissipation.
    *   **A356 (AlSi7Mg0.3):** Often used for sand or investment casting, this alloy offers good strength and ductility, especially after heat treatment (T6 condition). It is suitable for housings requiring higher structural integrity.
*   **Weight:** The weight of the aluminum housing depends on the motor's size and cooling design (e.g., air-cooled fins vs. liquid-cooling jackets). For a typical passenger BEV motor, the housing can weigh between **10 kg and 20 kg**.

## 2. Induction Motors (IM)

Induction motors, while generally less power-dense than PMSMs, are known for their robustness, reliability, and cost-effectiveness, as they do not require permanent magnets.

### 2.1. Rotor

The rotor is the key differentiator from a PMSM. The most common type is the squirrel-cage rotor.

*   **Material:** The rotor cage consists of conductive bars short-circuited by end rings. These are typically made from:
    *   **Aluminum:** Die-cast aluminum is the most common and cost-effective material for rotor cages. The entire cage, including bars and end rings, is often cast in a single process.
    *   **Copper:** For high-efficiency and high-performance induction motors, copper is used for the rotor bars and end rings. Copper's higher conductivity reduces rotor I²R losses, improving overall motor efficiency. A copper rotor cage can be 40-50% heavier than an equivalent aluminum one, but it can enable a reduction in the overall motor size and weight.
*   **Weight:** For a 150-200 kW induction motor, the aluminum rotor cage might weigh **5-8 kg**. A copper equivalent would be heavier, in the range of **8-12 kg**. The core of the rotor is made of stacked electrical steel laminations, similar to those used in the stator.

### 2.2. Stator Windings

The stator of an induction motor is functionally similar to that of a PMSM, containing copper windings to generate the rotating magnetic field.

*   **Material:** High-conductivity copper, typically **Grade C110 (ETP)**, is used for the windings. The choice between round wire and hairpin/flat wire depends on the desired power density and manufacturing cost.
*   **Weight:** The weight of copper in the stator windings is comparable to that of a PMSM of similar power rating, generally ranging from **10 kg to 20 kg** for a typical BEV application.

### 2.3. Stator and Rotor Core

*   **Material:** Laminated non-oriented electrical steel is used for both the stator and rotor cores to minimize eddy current losses.
*   **Grades:** Grades like **M19** or **M270-50A** (0.50 mm thickness) are common. The selection depends on the balance between cost and desired efficiency.
*   **Weight:** The total weight of the steel laminations in an induction motor is typically higher than in a PMSM of equivalent power, due to the IM's lower power density. For a 150-200 kW motor, the steel core weight can be in the range of **40 kg to 70 kg**.

### 2.4. Motor Housing

*   **Material:** Similar to PMSMs, induction motor housings are almost always made from cast aluminum alloys like **A380** or **A356** to provide structural support and effective heat dissipation.
*   **Weight:** Due to the larger size of induction motors for a given power output, the housing is often heavier, typically ranging from **15 kg to 25 kg**.

## 3. Shared Components and Materials

### 3.1. Motor Shaft

The shaft transmits torque from the rotor to the vehicle's drivetrain and must withstand high torsional and bending stresses.

*   **Material:** High-strength alloy steels are used for their durability and fatigue resistance.
    *   **AISI 4140 (42CrMo4):** A chromium-molybdenum alloy steel, it is a very common choice, offering an excellent balance of strength, toughness, and cost. It is typically used in a hardened and tempered condition.
    *   **AISI 4340 (34CrNiMo6):** A nickel-chromium-molybdenum alloy steel, it provides superior toughness and hardenability, especially in larger diameter shafts. It is often specified for very high-performance or heavy-duty applications.
*   **Dimensions and Weight:** The shaft's dimensions are dictated by the torque and speed requirements. For a typical passenger BEV motor, the shaft might have a diameter of 30-50 mm and a length of 200-400 mm, with a weight ranging from **3 kg to 8 kg**.

### 3.2. Bearings, Seals, and Fasteners

*   **Bearings:** High-speed, precision ball bearings are used to support the rotor shaft. These are made from specialized bearing steel (e.g., 52100 chrome steel) and may feature ceramic balls (silicon nitride) for high-performance applications to reduce friction and improve electrical insulation.
*   **Seals:** Elastomeric or PTFE seals are used to protect the motor's internals from contaminants and retain lubricants.
*   **Fasteners:** High-strength steel bolts and screws are used for assembly.

## Summary Table of Material Weights for a Typical 150 kW BEV Motor

| Component | Material | PMSM (Typical Weight) | Induction Motor (Typical Weight) |
| :--- | :--- | :--- | :--- |
| **Permanent Magnets** | NdFeB (N42SH or similar) | 1.8 - 3.0 kg | N/A |
| **Stator Windings** | Copper (C101/C110) | 10 - 18 kg | 12 - 20 kg |
| **Rotor Conductors** | N/A (Magnets) | N/A | Aluminum (5-8 kg) or Copper (8-12 kg) |
| **Electrical Steel** | Non-Oriented Silicon Steel | 35 - 55 kg | 45 - 75 kg |
| **Housing** | Aluminum (A380/A356) | 12 - 22 kg | 15 - 25 kg |
| **Shaft** | Alloy Steel (4140/4340) | 4 - 8 kg | 4 - 8 kg |
| **Total Estimated Weight** | | **~65 - 106 kg** | **~75 - 130 kg** |

*Note: These values are estimates and can vary significantly based on specific motor design, cooling technology, and performance targets.*

---
### References

[1] A comprehensive review of different electric motors for electric ... (n.d.).
[2] Additive Drives. (n.d.). *Rapid Prototyping of Electric Motors*.
[3] Allca-Pekarovic, A., et al. (2022, June 15). *Experimental Characterization and Modeling of a YASA P400 Axial Flux PM Traction Machine for Electric Vehicles*.
[4] Analysis and Simulation of Axial Flux Permanent Magnet Motors for ...*. (n.d.).
[5] Analysis of axial flux motor performance for traction motor applications. *COMPEL - The International Journal for Computation and Mathematics in Electrical and Electronic Engineering*, *38*(4), 1306–1322.
[6] Axial-flux permanent-magnet brushless dc traction motor for ... - Research*. (n.d.).
[7] Badewa, O. (2023). *Optimization of an Electric Vehicle Traction Motor with a PM Flux ...*.
[8] BEVI. (n.d.). *Electric motors*.
[9] BMW i3 (Entity Search Result)
[10] BMW i3 (I01): Engines & technical data | BMW.am.
[11] BMW i3 | Technical Specs, Fuel consumption, Dimensions.
[12] BMW i3 2014-present Drivetrain Specifications.
[13] BMW i3 Features and Specs - Car and Driver.
[14] BMW i3 : Technical data.
[15] BMW i3S Specification Guide-I01.
[16] Bosch Mobility. (n.d.). *Electric motor for commercial vehicles*.
[17] Comparative analysis of electric motor drives employed for propulsion ...
[18] Current progress and future challenges in rare-earth-free permanent magnets.
[19] DESIGN OF A NOVEL AXIAL-FLUX INDUCTION MACHINE FOR TRACTION ...*. (n.d.).
[20] Design and Control of Novel Axial Flux Electric Motors for Electric ...*. (n.d.).
[21] Design of a Yokeless double disc axial flux motor for light electric ...*. (n.d.).
[22] Despite Concerns Rare Earth Free Motors Take a Back Seat in EVs.
[23] Ding, J. (2024, October 12). *SWOT Analysis of Future Trends in BEV-related Technologies: Xiaomi Automobile Co., Ltd's Latest Product as a Case Study*. Advances in Economics, Management and Political Sciences, 109, 73-81.
[24] EasiMotor Online PMSM Training Nissan Leaf 2012 Case. (n.d.).
[25] Electric Motor R&D - Department of Energy. (n.d.).
[26] Electric Motor Thermal Management - NREL. (n.d.).
[27] Electric Motors - WEG. (n.d.).
[28] ELECTRIFIED VEHICLE TRACTION MACHINE DESIGN WITH MANUFACTURING ... - McMaster University. (n.d.).
[29] Electrification Series - All About Circuits
[30] ESR Motor Systems. (n.d.). *Marathon Electric Motors*.
[31] EV Motors Without Rare Earth Permanent Magnets - IEEE Spectrum.
[32] evcurvefuturist. (2024, December 13). *Evolution of the BEV Market*.
[33] Exentis Group. (n.d.). *Additive Screen Printing Technology for Renewable Energy*.
[34] Gartner. (2024, March 7). *Gartner Outlines a New Phase for Electric Vehicles*.
[35] Geometry of MOTOR1 (IPM, Nissan Leaf) - ResearchGate. (n.d.).
[36] High Performance Low Cost Electric Motor for Electric Vehicles Using Ferrite Magnets.
[37] Influence of Electrical Steel Grade on Different Types of Traction Motors - Academia.edu. (n.d.).
[38] JATO. (2024, March 21). *Electric Vehicle Trends 2024: Boom or Bust Future for EVs 2024*.
[39] Kirchner, C. (2025, June 25). *Three axial flux motors and 850 kW fast charging? Meet the GT XX.*
[40] Laczkowski, K., & Hertzke, P. (2025, February 10). *Extended-range electric vehicles: New OEM market?*.
[41] Landscaping and Review of Traction Motors for Electric Vehicle Applications
[42] MET3DP. (n.d.). *Electric Motor Rotor Support*.
[43] Młot, A., & Łukaniszyn, M. (2019, June 24).
[44] Modelling the Nissan Leaf Motor using Motor-CAD - selidori. (n.d.).
[45] MOTOR Information Systems. (n.d.). *Specifications*.
[46] Motors used in EVs – BLDC, Induction, SRM, Permanent Magnet Motors for ...
[47] Multi-Physics and Multi-Objective Design of an Axial Flux ... - MDPI*. (n.d.).
[48] Nidec Motor Corporation. (n.d.). *U.S. MOTORS Brand*.
[49] Oak Ridge National Laboratory. (n.d.). *Amiee Jackson*.
[50] Oak Ridge National Laboratory. (n.d.). *Applying additive manufacturing to replace windings in DC motors*.
[51] Performance Comparison of High-Speed Motors for Electric Vehicle - MDPI
[52] Permanent Magnet Motor in Model 3 Tesla
[53] phani babu. (2022, October 2). *PMSM Motor for Electric Vehicles*. ELECTRICAL ENGINEERING MATERIALS.
[54] PMSM and SRM- Electric Motors For EV, Advantage and Disadvantage
[55] PMSM Motor for Electric Vehicles: - ELECTRICAL ENGINEERING MATERIALS
[56] Power Electric. (n.d.). *Motor Resources*.
[57] Process performance motors - ABB. (n.d.).
[58] Rare Earth-Free Electric Motor Design for EV Traction Comparing Overall.
[59] Rare Earth-Free Motors for Medium and High-Power Vehicles.
[60] Rare Earth Free Motors Take Back Seat in EVs | MOTOR.
[61] Rare earth-free motors and EV components redefine innovation.
[62] Rare-earth free motors for electric vehicles | Chara Technologies.
[63] Reduced rare earth and magnet-free motors - E-Mobility Engineering.
[64] Rust, S.-M. (2024, October 29). *BEVs Remain Competitive: Why Electric Fleets Are a Smart Move...*.
[65] ScienceDirect. (2022). *Cost, range anxiety and future electricity supply: A review of how...*.
[66] ScienceDirect. (2024). *Projections of the costs of light-duty battery-electric and fuel cell...*.
[67] Scored a Nissan Leaf motor and transmission for $100 bucks ... - Reddit. (n.d.).
[68] Specs for all BMW i3 versions - Ultimate Specs.
[69] Switched reluctance motor (Entity Search Result)
[70] Technical specifications. BMW i3 (120 Ah).
[71] Tesla, Inc. (n.d.). *2020 Tesla Model S Specifications*.
[72] Tesla, Inc. (n.d.). *Dual Motor Model S*.
[73] Tesla’s All-New Interior Permanent Magnet Synchronous Reluctance Motor
[74] The Engineer. (2019, October 29). *3D printed stator promises more powerful electric motors*.
[75] U.S. Motors. (n.d.). *Datasheets*.
[76] USITC. (n.d.). *Electrifying the Global BEV Landscape: Top Suppliers and Consumers of...*.
[77] USP3D. (n.d.). *Innovative Electrical Machines*.
[78] VITO. (n.d.). *3D printing rotor and stator cores to create better electrical motors*.
[79] What is an Electric Motor? (n.d.).
[80] Yang, R. (2016). *ELECTRIFIED VEHICLE TRACTION MACHINE DESIGN WITH MANUFACTURING ...*.
[81] 2017-TSC-0986_final - refreedrive. (n.d.).
[82] 2020 Tesla Model S Performance (PMSR) All-wheel drive (AWD) Horsepower*. (n.d.).
[83] 2021 BMW i3 42 kWh - Specifications.
[84] (PDF) Comparative analysis of electric motor drives employed for ...
[85] https://digital-library.theiet.org/doi/10.1049/iet-epa.2019.0251
[86] https://elonbuzz.com/2025-tesla-all-new-motor-finally-hit-the-market-elon-musk-reveals/
[87] https://ietresearch.onlinelibrary.wiley.com/doi/epdf/10.1049/iet-epa.2020.0081
[88] https://ieeexplore.ieee.org/document/10068509
[89] https://ieeexplore.ieee.org/document/8360093
[90] https://link.springer.com/article/10.1007/s00202-025-03249-7
[91] https://www.inderscienceonline.com/doi/abs/10.1504/IJVNV.2021.120003
[92] https://www.findmyelectric.com/blog/tesla-pmsr-motor-raven-explained/
[93] https://www.researchgate.net/publication/33308202_Review_of_Switched_Reluctance_Motor_Control_for_Acoustic_Noise_and_Vibration_Reduction
[94] https://www.spiedigitallibrary.org/conference-proceedings-of-spie/12709/2684576/A-review-of-research-on-vibration-and-noise-reduction-in/10.1117/12.2684576.full
[95] http://www.cestems.org/uploads/20181225/15457069342055.pdf
[96] https://www.theworldmaterial.com/astm-sae-aisi-4140-steel/
[97] http://www.interlloy.com.au/data_sheets/high_tensile_steels/high_pdf/Interlloy_4140_High_Tensile_Steel.pdf
[98] https://atlassteels.com.au/wp-content/uploads/2021/09/Through-Hardening-Low-Alloy-Steel-Bar-4140-Grade-Data-Sheet-10-09-21-1.pdf
[99] https://www.tsmsteel.com/assets/pdf/alloy-steel/aisi-4140.pdf
[100] https://www.mwcomponents.com/uploads/Resource-Center/Elgin-Material-Sheets/Alloy-Steel-Grade-4140-Fact-Sheet_Elgin-Website.pdf
[101] https://www.steel-grades.com/Steel-Grades/Carbon-Steel/18/5242/_SAE_4140.pdf
[102] https://railwheels.en.made-in-china.com/product/NntpugZThyrj/China-AISI-4140-SAE-4340-Forged-Forging-Steel-Railway-Locomotive-DC-AC-Traction-Motors-Rotor-Shafts.html
[103] https://www.lfspecialsteel.com/showroom/aisi-4140-sae-4340-forged-forging-steel-railway-locomotive-dc-ac-traction-motors-rotor-shafts-armature-splined-spline-hollow-shafts-34crnimo6-42crmo4-1-7225-.html
[104] https://www.csmfg.com/Die-Casting-Aluminum.html
[105] https://www.metalcastingfactory.com/aluminum-die-casting-motor-housing/
[106] https://caldiecast.com/wp-content/uploads/2021/07/Aluminum-Alloy-Data_IN-2722.pdf
[107] https://www.sunrise-metal.com/aluminum-alloy-a380-properties/
[108] https://www.gabrian.com/a380-aluminum-alloy/
[109] https://aludiecasting.com/a380-aluminum-alloy-properties/
[110] https://www.theworldmaterial.com/weight-density-of-aluminum/
[111] https://www.makeitfrom.com/compare/5083-AlMg4.5Mn0.7-3.3547-N8-A95083-Aluminum/6061-AlMg1SiCu-3.3214-H20-A96061-Aluminum
[112] https://www.upmet.com/sites/default/files/datasheets/6061.pdf
[113] https://www.hydro.com/globalassets/01-products--services/extruded-profiles/americas/ena-resources/alloy-data-sheets/hydro_2019_data_sheet_6061.pdf
[114] https://jmproto.com/portfolio/motor-aluminum-alloy-casing/
[115] https://atlassteels.com.au/wp-content/uploads/2021/08/Aluminium-Alloy-5083-Data-Sheet-24-06-21.pdf
[116] https://www.alloyaluminum.com/aluminium-6061-vs-5083.html
[117] https://www.stanfordmagnets.com/rare-earth-consumption-and-the-uses-in-neodymium-magnets.html
[118] https://www.magnetapplications.com/blog/limiting-heavy-rare-earths-reliance-for-neodymium-magnets
[119] https://techmetalsobservatory.org/technology-metals-components-and-products/technology-metals/rare-earth-elements.html
[120] https://www.arnoldmagnetics.com/wp-content/uploads/2017/10/Important-Role-of-Dysprosium-in-Modern-Permanent-Magnets-150906.pdf
[121] https://www.couragemagnet.com/magnet-faqs/865.html
[122] https://www.sciencedirect.com/science/article/pii/S2214993716300641
[123] https://www.google.com/search?q=Dysprosium&kgmid=/m/01011w
[124] https://www.wieland-rolledproductsna.com/wp-content/uploads/2018/08/Olin-Brass-Copper-Alloy-C110-Data-Sheet.pdf
[125] https://columbiametals.com/wp-content/uploads/2023/10/Copper.pdf
[126] https://www.smithmetal.com/pdf/copper/c101.pdf
[127] https://shop.machinemfg.com/copper-c101-composition-uses-and-properties/
[128] https://www.grefeemold.com/wp-content/uploads/2021/12/34-Copper-C101.pdf
[129] https://www.aircraftmaterials.com/data/copper/c101.html
[130] https://www.holmedodsworth.com/data-sheets/c101-cw004a-etp-copper
[131] https://tirapid.com/copper-101-vs-110/
[132] https://www.tlclam.net/capabilities/motor-laminations/
[133] https://www.brown.edu/Departments/Engineering/Courses/ENGN1931F/mag_cores_dataAKSteel-very%20good.pdf
[134] http://protolam.com/page7.html
[135] https://lammotor.com/select-right-grade-of-silicon-steel/
[136] https://www.copper.org/environment/sustainable-energy/electric-motors/education/motor-rotor/production/proc03/process_03_31.html
[137] https://www.polarislaserlaminations.com/material-in-stock.html
[138] https://www.gneesiliconsteel.com/blog/a-general-guide-to-m19-silicon-steel.html
[139] https://www.refreedrive.eu/wp-content/downloads/WMM20_Popescu_Electrical_Steel_and_Motors_performances-Role_of_Lamination_Thickness.pdf
[140] https://www.thyssenkrupp-steel.com/en/products/electrical-steel/electrical-steel-non-grain-oriented/powercore-a/powercore-a.html
[141] https://ssc.arcelormittal.com/IMG/pdf/electricalsteelsbrochure_en.pdf
[142] https://cms.sij.si/storage/302/SIWATT-M270-35A.pdf
[143] https://www.ei-lamination.com/specified-silicon-steel-material/
[144] https://www.thyssenkrupp-steel.com/en/products/electrical-steel/electrical-steel-non-grain-oriented/powercore-a/powercore-a.html
[145] https://www.eai.in/blog/2018/12/comparison-of-various-motors-used-in-ev.html
[146] https://www.refreedrive.eu/wp-content/uploads/2020/09/D3.1-Report-on-the-design-of-the-IM-and-SynRel-motors-without-magnets.pdf
[147] https://www.copper.org/applications/automotive/motor-rotor/pdf/a6132-copper-rotor-motor-efficiency.pdf
[148] https://www.copper.org/applications/automotive/motor-rotor/pdf/a6132-copper-rotor-motor-efficiency.pdf
[149] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[150] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[151] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[152] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[153] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[154] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[155] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[156] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[157] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[158] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[159] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[160] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[161] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[162] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[163] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[164] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[165] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[166] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[167] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[168] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[169] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[170] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[171] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[172] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[173] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[174] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[175] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[176] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[177] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[178] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[179] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[180] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[181] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[182] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[183] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[184] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[185] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[186] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[187] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[188] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[189] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[190] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[191] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[192] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[193] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[194] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[195] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[196] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[197] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[198] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[199] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[200] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[201] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[202] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[203] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[204] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[205] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[206] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[207] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[208] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[209] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[210] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[211] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[212] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[213] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[214] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[215] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[216] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[217] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[218] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[219] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[220] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[221] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[222] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[223] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[224] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[225] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[226] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[227] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[228] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[229] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[230] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[231] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[232] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[233] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[234] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[235] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[236] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[237] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[238] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[239] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[240] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[241] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[242] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[243] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[244] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[245] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[246] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[247] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[248] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[249] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[250] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[251] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[252] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[253] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[254] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[255] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[256] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[257] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[258] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[259] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[260] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[261] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[262] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[263] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[264] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[265] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[266] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[267] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[268] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[269] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[270] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[271] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[272] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[273] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[274] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[275] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[276] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[277] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[278] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[279] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[280] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[281] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[282] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[283] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[284] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[285] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[286] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[287] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[288] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[289] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[290] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[291] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[292] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[293] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[294] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[295] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[296] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[297] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[298] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[299] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[300] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[301] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[302] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[303] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[304] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[305] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[306] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[307] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[308] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[309] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[310] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[311] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[312] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[313] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[314] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[315] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[316] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[317] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[318] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[319] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[320] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[321] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[322] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[323] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[324] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[325] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[326] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[327] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[328] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[329] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[330] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[331] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[332] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[333] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[334] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[335] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[336] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[337] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[338] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[339] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[340] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[341] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[342] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[343] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[344] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[345] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[346] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[347] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[348] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[349] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[350] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[351] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[352] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[353] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[354] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[355] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[356] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[357] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[358] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[359] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[360] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[361] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[362] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[363] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[364] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[365] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[366] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[367] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[368] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[369] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[370] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[371] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[372] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[373] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[374] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[375] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[376] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[377] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[378] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[379] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[380] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[381] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[382] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[383] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[384] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[385] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[386] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[387] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[388] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[389] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[390] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[391] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[392] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[393] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[394] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[395] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[396] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[397] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[398] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[399] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[400] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[401] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[402] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[403] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[404] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[405] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[406] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[407] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[408] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[409] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[410] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[411] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[412] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[413] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[414] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[415] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[416] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[417] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[418] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[419] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[420] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[421] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[422] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[423] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[424] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[425] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[426] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[427] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[428] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[429] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[430] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[431] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[432] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[433] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[434] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[435] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[436] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[437] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[438] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[439] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[440] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[441] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
[442] https://www.researchgate.net/publication/320240135_Design_of_a_squirrel_cage_induction_motor_for_electric_vehicle_applications
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       -                                                                                                                            -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      -                                                              -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               -                                                                                                                            -                                                                                             -                                                                                                                                                                                          -                               -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             -                               -                                                                                                                            -
| **Mechanical Properties** | **A380 (Gabrian)** | **A380 (Aludiecasting)** | **A383 (Gabrian)** | **A383 (Aludiecasting)** | **Notes**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      -                                                                                                                                                                                          -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     -                               -                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           -                                                              -                                                              -                               -                                                                                                                            -                               -                                                              -                                                              -                                                                                                                                                                                                                         -                               I'_
| Ultimate Tensile Strength | 47,000 psi (324 MPa) | 324 MPa (47 ksi) | 45,000 psi (310 MPa) | 310 MPa (45 ksi) | A380 has slightly higher tensile strength, making it suitable for applications requiring high strength and rigidity [https://www.gabrian.com/a380-aluminum-alloy/]. |
| Yield Strength          | 23,000 psi (159 MPa) | 160 MPa (23 ksi) | 22,000 psi (152 MPa) | 150 MPa (22 ksi) | A380's higher yield strength indicates better resistance to permanent deformation under load [https://www.gabrian.com/a380-aluminum-alloy/]. |
| Elongation              | 3.5% in 2 inches | 3.5% in 50 mm | 3.5% in 2 inches | 3.5% in 50 mm | Both alloys have similar elongation, indicating comparable ductility [https://www.gabrian.com/a380-aluminum-alloy/]. |
| Hardness (Brinell)      | 80 HB          | 80 HB          | 75 HB          | 75 HB          | A380 is slightly harder, offering better wear resistance [https://www.gabrian.com/a380-aluminum-alloy/]. |
| Shear Strength          | 27,000 psi (186 MPa) | 190 MPa (27 ksi) | 25,0t00 psi (172 MPa) | 170 MPa (25 ksi) | A380's higher shear strength is beneficial for components under shear stress [https://www.gabrian.com/a380-aluminum-alloy/]. |
| Fatigue Strength        | 20,000 psi (138 MPa) | 140 MPa (20 ksi) | 20,000 psi (138 MPa) | 140 MPa (20 ksi) | Both alloys have similar fatigue strength, crucial for components subjected to cyclic loading [https://www.gabrian.com/a380-aluminum-alloy/]. |
| Thermal Conductivity    | 96 W/mK        | 96 W/mK        | 96 W/mK        | 96 W/mK        | Both alloys have identical thermal conductivity, making them equally effective for heat dissipation in motor housings [https://www.gabrian.com/a380-aluminum-alloy/]. |
| Density                 | 2.71 g/cm³     | 2.71 g/cm³     | 2.71 g/cm³     | 2.71 g/cm³     | The density is the same for both alloys, so weight will be determined by the part's volume [https://www.gabrian.com/a380-aluminum-alloy/]. |

### A383 Aluminum Alloy: A High-Fluidity Alternative

A383 (ANSI/AA A383.0) is a modification of A380, specifically designed for applications requiring intricate components and thin walls [https://caldiecast.com/wp-content/uploads/2021/07/Aluminum-Alloy-Data_IN-2722.pdf]. While it shares many properties with A380, its composition is adjusted to enhance its die-filling characteristics.

### Chemical Composition

The key difference in the composition of A383 compared to A380 is the higher silicon content and lower copper content:

| SL. No. | Element | A383 (Gabrian) | A383 (Aludiecasting) | Role and Impact |
| :------ | :------ | :------------- | :------------------- | :--------------- |
| 1       | Silicon (Si) | 9.5-11.5%      | 9.5-11.5%            | Higher silicon content improves fluidity, making it ideal for complex castings with thin sections. It also reduces the tendency for hot cracking [https://www.gabrian.com/a380-aluminum-alloy/]. |
| 2       | Copper (Cu) | 2-3%           | 2.0-3.0%             | Lower copper content compared to A380, which slightly reduces strength but improves ductility and corrosion resistance [https://www.gabrian.com/a380-aluminum-alloy/]. |
| 3       | Iron (Fe) | ≤1.3%          | 0.5-1.3%             | Similar to A380, prevents die sticking [https://www.gabrian.com/a380-aluminum-alloy/]. |
| 4       | Magnesium (Mg) | ≤0.1%          | 0.1% max             | Low magnesium content to maintain good castability [https://www.gabrian.com/a380-aluminum-alloy/]. |
| 5       | Manganese (Mn) | ≤0.5%          | 0.5% max             | Similar to A380, improves toughness [https://www.gabrian.com/a380-aluminum-alloy/]. |
| 6       | Nickel (Ni) | ≤0.3%          | 0.3% max             | Lower nickel content compared to A380 [https://www.gabrian.com/a380-aluminum-alloy/]. |
| 7       | Tin (Sn) | ≤0.15%         | 0.15% max            | Lower tin content compared to A380 [https://www.gabrian.com/a380-aluminum-alloy/]. |
| 8       | Zinc (Zn) | ≤3%            | 3.0% max             | Similar to A380 [https://www.gabrian.com/a380-aluminum-alloy/]. |

### Physical and Mechanical Properties

A383 offers a slightly different balance of properties compared to A380:

*   **Strength:** A383 has slightly lower tensile and yield strength than A380 due to its lower copper content.
    *   Ultimate Tensile Strength: 45,000 psi (310 MPa) [https://www.gabrian.com/a380-aluminum-alloy/].
    *   Yield Strength: 22,000 psi (152 MPa) [https://www.gabrian.com/a380-aluminum-alloy/].
*   **Hardness:** Slightly softer than A380, with a Brinell hardness of 75 HB [https://www.gabrian.com/a380-aluminum-alloy/].
*   **Ductility:** Similar elongation to A380 (3.5% in 2 inches) [https://www.gabrian.com/a380-aluminum-alloy/].
*   **Thermal Conductivity:** Identical to A380 at 96 W/mK [https://www.gabrian.com/a380-aluminum-alloy/].
*   **Density:** Same as A380 at 2.71 g/cm³ [https://www.gabrian.com/a380-aluminum-alloy/].

### Key Differences and Application Considerations for Motor Housings

The choice between A380 and A383 for a motor housing depends on the specific design requirements:

*   **Strength vs. Castability:** A380 is the stronger of the two alloys, making it suitable for motor housings that require higher mechanical strength and rigidity. A383, with its superior fluidity, is the better choice for housings with very complex geometries, thin walls, or intricate details that are difficult to fill during the casting process [https://www.sunrise-metal.com/aluminum-alloy-a380-properties/], [https://www.gabrian.com/a380-aluminum-alloy/].
*   **Hot Cracking Resistance:** A383 has better resistance to hot cracking (cracking during solidification) due to its higher silicon content. This makes it more suitable for complex castings that are prone to stress during cooling [https://www.gabrian.com/a380-aluminum-alloy/].
*   **Pressure Tightness:** A383 is often preferred for applications requiring pressure tightness, such as housings for liquid-cooled motors, as its excellent die-filling characteristics help to minimize porosity [https://caldiecast.com/wp-content/uploads/2021/07/Aluminum-Alloy-Data_IN-2722.pdf].
*   **Cost:** A380 is generally more cost-effective and widely available, making it the go-to choice for many applications. A383 might be slightly more expensive due to its more specific composition and application focus.

### Weight of Motor Housings

The weight of an aluminum die-cast motor housing is primarily determined by its volume and the density of the alloy used. Since both A380 and A383 have the same density of **2.71 g/cm³**, the weight of a housing made from either alloy will be identical if the design is the same.

However, the choice of alloy can indirectly influence the weight. For instance, if a design requires very thin walls to save weight, A383 might be the only viable option due to its superior fluidity, allowing for a lighter final part. Conversely, if a certain strength is required, a designer might be able to use less material with the slightly stronger A380 alloy, potentially leading to a lighter design.

The actual weight of a motor housing can vary significantly depending on the size and power of the motor. For a typical BEV traction motor, the aluminum housing can weigh anywhere from **10 kg to 25 kg**.

### Manufacturing and Post-Processing

Both A380 and A383 are well-suited for high-pressure die casting, a process that allows for high-volume production with excellent dimensional accuracy and surface finish [https://www.csmfg.com/Die-Casting-Aluminum.html]. After casting, motor housings often undergo secondary operations:

*   **CNC Machining:** To create precise features like bearing seats, mounting holes, and sealing surfaces.
*   **Surface Finishing:** Options include shot blasting, powder coating, anodizing, or chromating to enhance corrosion resistance and aesthetic appeal [https://www.metalcastingfactory.com/aluminum-die-casting-motor-housing/].
*   **Impregnation:** For applications requiring high pressure tightness, the casting may be impregnated with a sealant to close any micro-porosity.

### Conclusion

A380 and A383 are both excellent choices for aluminum die-cast motor housings, each with specific advantages.

*   **A380** is the workhorse alloy, offering a superb balance of strength, thermal conductivity, and cost-effectiveness. It is the ideal choice for a wide range of motor housings where manufacturability is not a major concern.
*   **A383** is a specialized version of A380, engineered for superior castability. It is the preferred alloy for motor housings with intricate designs, thin walls, or a high requirement for pressure tightness, even at the cost of slightly lower mechanical strength compared to A380.

The weight of the motor housing will be primarily determined by the design's volume, as both alloys share the same density. The selection between the two will depend on a careful analysis of the trade-offs between the mechanical requirements of the housing and the complexity of its design.

---

## Query 5: "motor shaft steel grade 4140 4340 dimensions weight BEV traction"
The motor shaft is a critical component in any electric motor, especially in high-performance applications like Battery Electric Vehicle (BEV) traction systems. It is responsible for transmitting the torque generated by the motor to the wheels, and as such, it must withstand significant torsional, bending, and fatigue stresses. The selection of the right material and design for the motor shaft is paramount to ensure reliability, durability, and safety. Among the most commonly used materials for such demanding applications are high-strength alloy steels, with AISI 4140 and AISI 4340 being prominent choices.

This analysis will provide a detailed examination of these two steel grades, their properties, and their suitability for BEV traction motor shafts, including considerations for dimensions and weight.

### AISI 4140: The Versatile and Robust Choice

AISI 4140, also known as SAE 4140, is a chromium-molybdenum (Cr-Mo) alloy steel that is widely used for its excellent combination of strength, toughness, and wear resistance. It is often supplied in a hardened and tempered condition, making it ready for use in high-stress applications.

#### Chemical Composition of AISI 4140 (UNS G41400)

*   **Carbon (C):** 0.38 - 0.43%
*   **Manganese (Mn):** 0.75 - 1.00%
*   **Phosphorus (P):** ≤ 0.035%
*   **Sulfur (S):** ≤ 0.040%
*   **Silicon (Si):** 0.15 - 0.35%
*   **Chromium (Cr):** 0.80 - 1.10%
*   **Molybdenum (Mo):** 0.15 - 0.25%

The chromium content provides good hardness penetration, and the molybdenum imparts uniformity of hardness and high strength.

#### Mechanical Properties of AISI 4140

The mechanical properties of AISI 4140 can be significantly altered through heat treatment. In the quenched and tempered condition (typically to a tensile strength of 850-1000 MPa), it offers:

*   **High Tensile Strength:** Typically in the range of 850 - 1000 MPa.
*   **Good Yield Strength:** A high yield strength ensures the shaft can withstand high loads without permanent deformation.
*   **Excellent Toughness:** The ability to absorb energy and resist fracture is crucial for a component subjected to dynamic loads.
*   **High Fatigue Strength:** This is critical for motor shafts, which experience continuous rotational and torsional stresses.
*   **Good Wear Resistance:** The surface hardness achievable with 4140 makes it resistant to wear and abrasion.

#### Applications in Traction Motors

AISI 4140 is explicitly used for manufacturing shafts for various types of motors, including those for railway locomotives. For instance, it is a specified material for **forged rotor shafts for DC and AC traction motors** [Source 5, Source 7]. The forging process further enhances the steel's grain structure, improving its strength and fatigue resistance. Its high strength-to-weight ratio is also a significant advantage in automotive applications, where minimizing weight is crucial for efficiency [Source 3].

### AISI 4340: The High-Strength, High-Toughness Option

AISI 4340 is a nickel-chromium-molybdenum (Ni-Cr-Mo) alloy steel, known for its exceptional strength, toughness, and fatigue resistance, particularly in large cross-sections. It is often considered a step up from 4140 for more demanding applications.

#### Chemical Composition of AISI 4340 (UNS G43400)

While not explicitly detailed in the provided search results, the typical composition of AISI 4340 includes:

*   **Carbon (C):** 0.38 - 0.43%
*   **Manganese (Mn):** 0.60 - 0.80%
*   **Silicon (Si):** 0.15 - 0.35%
*   **Chromium (Cr):** 0.70 - 0.90%
*   **Molybdenum (Mo):** 0.20 - 0.30%
*   **Nickel (Ni):** 1.65 - 2.00%

The key difference from 4140 is the significant addition of **nickel**, which greatly improves hardenability and toughness.

#### Mechanical Properties of AISI 4340

AISI 4340 can be heat-treated to achieve very high strength levels while maintaining good toughness, making it one of the strongest and toughest engineering steels available.

*   **Superior Hardenability:** The nickel content allows 4340 to be hardened uniformly through larger cross-sections than 4140. This is critical for large-diameter motor shafts to ensure consistent mechanical properties from the surface to the core.
*   **Exceptional Toughness and Impact Strength:** It exhibits excellent resistance to shock and impact loads, even at high strength levels.
*   **High Fatigue and Creep Resistance:** These properties make it ideal for shafts subjected to high cyclic stresses and elevated operating temperatures.

#### Applications in Traction Motors

Similar to 4140, AISI 4340 is also specified for **forged rotor shafts for railway locomotive DC and AC traction motors** [Source 5, Source 7]. Its use in such heavy-duty applications underscores its suitability for high-performance BEV traction motors where maximum power density and reliability are required. It is often the material of choice for applications where failure is not an option, such as in aircraft landing gear and other critical structural components.

### Comparison: 4140 vs. 4340 for BEV Motor Shafts

| Feature | AISI 4140 | AISI 4340 | Relevance to BEV Motor Shafts |
| :--- | :--- | :--- | :--- |
| **Primary Alloying Elements** | Cr, Mo | Ni, Cr, Mo | The addition of Nickel in 4340 significantly enhances its properties. |
| **Strength** | High | Very High | Both are suitable, but 4340 offers a higher strength ceiling for more demanding designs. |
| **Toughness** | Good | Excellent | 4340's superior toughness provides a greater safety margin against fracture from shock loads. |
| **Hardenability** | Good | Excellent | For larger diameter shafts, 4340's ability to harden through the entire cross-section is a major advantage. |
| **Cost** | Lower | Higher | 4140 is a more cost-effective solution for many applications, while 4340 is reserved for when its superior properties are essential. |
| **Common Use** | General-purpose high-stress parts, shafts, gears. | Critical, high-stress components, large shafts, aircraft parts. |

For a BEV traction motor, the choice between 4140 and 4340 would depend on the specific performance targets. A standard passenger EV might use a 4140 shaft, which provides more than adequate performance. A high-performance sports EV or a heavy-duty electric truck, however, might specify a 4340 shaft to handle the higher torque, power, and potential shock loads, especially in larger motor designs.

### Dimensions and Weight of BEV Traction Motor Shafts

The dimensions of a motor shaft are determined by a complex engineering analysis that considers torque, rotational speed, bearing placement, and the geometry of the rotor and output coupling.

*   **Diameter:** The shaft diameter is a critical dimension, directly related to its ability to resist torsional stress. For passenger BEV motors, shaft diameters can range from approximately **30 mm to 60 mm**.
*   **Length:** The length is determined by the overall motor design, including the length of the rotor core and the placement of bearings. It can range from **200 mm to over 500 mm**.
*   **Features:** Motor shafts are not simple cylinders. They often feature steps, keyways, splines (as mentioned for 4140/4340 shafts [Source 7]), and threaded ends for mounting rotors, bearings, and output gears. Some designs may even be hollow to reduce weight or allow for internal cooling.
*   **Weight:** The weight of the shaft is a function of its dimensions and the density of the steel. The density of both 4140 and 4340 steel is approximately **7.85 g/cm³ (0.284 lb/in³)**.
    *   A solid shaft with a diameter of 40 mm and a length of 300 mm would have a volume of approximately 377 cm³. Its weight would be approximately **2.96 kg**.
    *   A larger shaft, perhaps for a more powerful motor, with a diameter of 50 mm and a length of 400 mm, would have a volume of approximately 785 cm³ and a weight of around **6.16 kg**.

These are simplified calculations, and the actual weight will vary based on the specific geometry, including any steps, tapers, or hollow sections. However, they provide a reasonable estimate of the mass contribution of the shaft to the overall motor assembly.

### Conclusion

Both AISI 4140 and AISI 4340 are excellent choices for BEV traction motor shafts, offering the high strength, toughness, and fatigue resistance required for this demanding application.

*   **AISI 4140** represents a robust, versatile, and cost-effective solution suitable for a wide range of BEV applications. Its proven performance in similar high-stress environments like railway traction motors makes it a reliable choice.
*   **AISI 4340** is a premium material for applications where the highest levels of performance are required. Its superior hardenability and toughness make it the preferred option for larger, more powerful motors or in designs where safety and reliability are absolutely critical.

The final selection will be driven by a detailed engineering analysis of the specific loads, operating conditions, and cost targets for the BEV powertrain. The dimensions and weight of the shaft are a direct consequence of these design choices, with a typical passenger BEV motor shaft weighing between 3 and 8 kilograms.